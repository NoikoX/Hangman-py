from random import randint # Do not delete this line

def displayIntro():
    # TODO
    pass

def displayEnd(result):
    # TODO
    pass
            
def displayHangman(state):
    # TODO
    pass

def getWord():
    # TODO
    pass

def valid(c):
    # TODO
    pass

def play():
    # TODO
    pass

def hangman():
    while True:
        displayIntro()
        result = play()
        displayEnd(result)
        # TODO

if __name__ == "__main__":
    hangman()

